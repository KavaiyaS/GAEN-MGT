# GAEn/MGT — Reproducible Code

See `data/external_links.txt` for dataset sources. Use `scripts/generate_splits.py` then run baselines/ablations and GAEn training.
